# Workplace Assist

**Enterprise Unified Device AI — Silent Background Endpoint Diagnostics**

> Version 1.0.0 · Python 3.12 · FastAPI + Electron 32 · Multi-provider AI

---

## Overview

Workplace Assist is a production-ready, enterprise-grade endpoint intelligence platform. It runs silently in the system tray, continuously monitors device health, correlates Windows Event Log signals with live telemetry, and delivers context-aware AI diagnostics through a per-tab floating chat interface.

The application is built on a **hybrid AI architecture**:
- **On-device SLM** (Ollama local models): real-time anomaly detection, log summarisation, fast triage
- **Cloud LLM** (Claude API / OpenAI API): deep root cause correlation, remediation generation, predictive insights

All analysis is **tab-scoped** — the Analyze button in Applications shows only application behavioural insights; Battery shows only battery diagnostics. There is zero cross-tab data leakage.

---

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│                    Electron Shell (UI)                   │
│  ┌──────────────┐  ┌──────────────┐  ┌───────────────┐  │
│  │  Dashboard   │  │  Tray Icon   │  │  Alert Popup  │  │
│  │  (renderer/) │  │  (JS tray)   │  │  (popup.html) │  │
│  └──────┬───────┘  └──────┬───────┘  └───────┬───────┘  │
│         └─────────────────┼──────────────────┘          │
│                    HTTP / WebSocket                      │
│                    127.0.0.1:8765                        │
└─────────────────────────────────────────────────────────┘
                           │
┌──────────────────────────▼──────────────────────────────┐
│               Python FastAPI Backend                     │
│  ┌────────────┐  ┌────────────┐  ┌────────────────────┐  │
│  │  Metric    │  │  Alert     │  │  AI Diagnostic     │  │
│  │  Scheduler │  │  Manager   │  │  Engine            │  │
│  └─────┬──────┘  └─────┬──────┘  └────────┬───────────┘  │
│        │               │                  │              │
│  ┌─────▼───────────────────────────────────▼──────────┐  │
│  │              Agent Collectors                       │  │
│  │  CPU · Memory · Disk · Network · GPU · Processes    │  │
│  │  Applications · Battery · Security · Event Log      │  │
│  └─────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────┘
```

---

## Features

### Monitoring Tabs

| Tab | Data | Metrics Shown |
|-----|------|---------------|
| **AI Chat** | Full context | Conversational diagnostics, quick actions |
| **Processes** | psutil live | CPU%, Memory, Status, Threads — kill button |
| **Applications** | ECG 60-min | Behavioral waveform, health score, crash/hang detection |
| **Battery** | BatteryCollector | Level, health score, drain rate, top draining apps, tips |
| **Security** | SecurityCollector | AV/BitLocker/Firewall compliance, threats, anomalies |
| **Alerts** | AlertManager | 1-hour rolling window, severity filter, acknowledge |
| **Event Analysis** | Windows Event Log | EUC AI Diagnostics Engine — full structured 9-section report |

### System Metrics Location
CPU, Memory, Disk I/O, and Network metric cards appear **only in the Processes tab**. All other tabs show domain-specific content exclusively.

### Floating Analyze Button (FAB)
Every monitoring tab has a circular floating action button (FAB) in the bottom-right corner. Clicking it opens a **per-tab AI chat popup** that:
- Runs AI analysis scoped strictly to that tab's domain
- Displays Root Cause, Impacted Components, Recommendations, Prevention tips
- Provides Quick Action buttons (Kill Top Process, Clear Temp, Reset Network, etc.)
- Supports **Re-analyze** and **Clear chat** actions
- Persists the analysis session within the tab until cleared
- Includes **ServiceNow Ticket** shortcut

### Event Analysis — EUC AI Diagnostics Engine

The Event Analysis tab is a full-panel structured diagnostics report — no split view. It reads the Windows Event Log and renders 9 insight sections:

1. **AI Summary** — Device health status, event totals, high-level assessment
2. **Critical Issues** — Top critical/error events with timestamp, source, Event ID
3. **Root Cause Analysis** — Correlated cause, contributing factors, confidence score
4. **Impact Assessment** — User productivity impact, affected workloads
5. **Pattern & Trend Analysis** — Recurring sources, volume patterns, anomaly flags
6. **Predictive Insights** — Memory exhaustion, disk failure, app stability warnings
7. **Recommended Remediation** — Auto-Fix / Guided Fix / IT Action with success probability
8. **Issue Timeline** — Chronological latest 5 events with severity markers
9. **Confidence Score** — Visual bar with percentage

The FAB button opens the same per-tab chat popup for follow-up AI dialogue.

---

## Installation

### Prerequisites

| Tool | Version |
|------|---------|
| Python | 3.10+ (3.12 recommended) |
| Node.js | 18+ |
| npm | 9+ |
| Windows | 10/11 x64 (primary) |

### Quick Start (Development)

```bash
cd sysassist
pip install -r requirements.txt
python main.py --agent
# Dashboard: http://127.0.0.1:8765
```

### Production Build

```bash
python copy_renderer.py
python backend_build.py      # builds SysAssistBackend.exe (~5 min)
npm install
npm run build                # outputs installer to dist/
```

---

## Project Structure

```
sysassist/
├── main.py                   # Entry: --agent | --tray | --headless
├── launcher.py               # Tray launcher (pystray)
├── requirements.txt
├── package.json              # Electron + build config
├── backend_build.py          # PyInstaller script
├── copy_renderer.py          # Copies ui/ → renderer/
│
├── config/
│   ├── config.json           # Runtime configuration
│   └── settings.py
│
├── agent/
│   ├── scheduler.py          # Metric orchestrator
│   ├── collector.py          # CPU/Memory/Disk/Network/GPU
│   ├── app_collector.py      # Application ECG (60-min history)
│   ├── battery.py            # Battery health + drain analysis
│   ├── security.py           # AV/BitLocker/Firewall compliance
│   ├── detector.py           # Threshold violations
│   ├── analyzer.py           # Pattern analysis
│   ├── health.py             # Health score
│   ├── context_builder.py    # DiagnosticContext assembly
│   └── buffer.py             # Rolling metric buffers
│
├── ai/
│   └── diagnostic.py         # OllamaClient + ClaudeClient + OpenAIClient
│
├── api/
│   └── server.py             # FastAPI — 38+ endpoints + WebSocket /ws
│
├── alerts/
│   ├── manager.py            # Alert lifecycle + cooldowns
│   └── state_manager.py      # Smart popup state machine
│
├── integrations/
│   └── servicenow.py         # ServiceNow REST API (Basic Auth)
│
├── remediation/
│   └── actions.py            # Kill, clear-temp, reset-network, optimize-memory
│
├── service/
│   └── windows_service.py    # Windows Service wrapper
│
├── utils/
│   ├── logger.py             # Structured logging + crash handler
│   └── storage.py            # Encrypted local storage (Fernet)
│
├── ui/
│   └── index.html            # Master dashboard source (136 KB)
│
├── renderer/
│   └── index.html            # Auto-generated for Electron
│
└── electron/
    ├── main.js               # Electron main process
    ├── backend-manager.js    # Silent Python spawner (CREATE_NO_WINDOW)
    ├── tray-manager.js       # System tray + health indicator
    ├── window-manager.js     # Dashboard + popup window management
    ├── alert-poller.js       # WebSocket → native notifications
    ├── preload.js            # Context bridge IPC
    └── renderer/popup.html   # Alert popup window
```

---

## API Reference

All endpoints on `http://127.0.0.1:8765`.

### Core Metrics

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/metrics` | Live CPU, Memory, Disk, Network, GPU |
| GET | `/api/processes` | All processes with CPU/Memory |
| GET | `/api/device/info` | Hostname, OS, CPU, RAM |
| GET | `/api/apps` | Application ECG timeline + insights |
| GET | `/api/battery` | Battery health, drain, consumers |
| GET | `/api/security` | Compliance score + threats |
| GET | `/api/events/logs?limit=N` | Windows Event Log (Critical/Error/Warning) |
| WS  | `/ws` | Live metrics stream (5s interval) |

### AI Analysis

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/analyze` | Full system analysis |
| POST | `/api/analyze/tab/{tab}` | Tab-scoped analysis |
| POST | `/api/chat` | Chat with AI |
| GET | `/api/ai/status` | Provider + model status |
| POST | `/api/ai/set/local` | Set Ollama model |
| POST | `/api/ai/set/apikey` | Set Claude/OpenAI key |
| GET | `/api/ai/models/local` | List Ollama models |

#### Tab-Scoped Analysis Values

| `{tab}` | Domain Analysed |
|---------|----------------|
| `procs` | Top 15 processes — CPU hogs, zombie, suspicious |
| `apps` | Application behaviour — crashes, hangs, health |
| `battery` | Drain rates, health score, charging advice |
| `security` | Disabled controls, PowerShell remediation |
| `events` | Windows Event Log correlation |

### Alerts

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/alerts/recent?hours=1` | 1-hour rolling alert window |
| POST | `/api/alerts/{id}/acknowledge` | Acknowledge alert |
| GET | `/api/alerts/{id}/diagnosis` | AI diagnosis for alert |

### Remediation

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/remediation/kill` | Kill process by PID |
| POST | `/api/remediation/clear-temp` | Clear temp files |
| POST | `/api/remediation/reset-network` | Reset Winsock + DNS |
| POST | `/api/remediation/optimize-memory` | Empty standby cache |

### ServiceNow

`POST /api/servicenow/ticket`

```json
{
  "instance": "https://your-instance.service-now.com",
  "username": "admin",
  "password": "••••••••",
  "alert_id": "alert_1710000000000_cpu"
}
```

**Requirements:** User must have the `itil` role.

---

## AI Engine Configuration

### Local LLM (Ollama — Recommended)

```bash
# Install: https://ollama.com
ollama pull phi3        # 3.8B — fast
ollama pull llama3.2    # 3B — balanced
ollama pull mistral     # 7B — thorough
```

Dashboard → AI Engine → Local LLM → Select → Connect

### Claude API

Dashboard → AI Engine → Claude API → Enter key → Connect  
Models: `claude-haiku-4-5-20251001`, `claude-sonnet-4-5`, `claude-opus-4-5`

### OpenAI API

Dashboard → AI Engine → OpenAI API → Enter key → Connect  
Models: `gpt-4o-mini`, `gpt-4o`, `gpt-4-turbo`, `o1-mini`

> Keys are **memory only** — never written to disk.

---

## Configuration (`config/config.json`)

```json
{
  "server": { "host": "127.0.0.1", "port": 8765 },
  "monitoring": {
    "intervals": { "cpu":5, "memory":10, "disk":60, "network":30, "gpu":5, "processes":10 },
    "window_size": 12,
    "sustained_ratio": 0.70
  },
  "thresholds": {
    "cpu":     { "warning":60,  "critical":85 },
    "memory":  { "warning":50,  "critical":80 },
    "disk":    { "warning":75,  "critical":90 },
    "gpu":     { "warning":60,  "critical":90 },
    "network_latency": { "warning":200, "critical":500 }
  },
  "alerts": {
    "cooldown_seconds": { "critical":120, "warning":300, "info":600 }
  }
}
```

---

## Silent Background Execution

```javascript
// electron/backend-manager.js
const CREATE_NO_WINDOW = 0x08000000;
spawnOpts.creationflags = CREATE_NO_WINDOW;
spawnOpts.windowsHide  = true;
spawnOpts.stdio        = ['ignore', 'pipe', 'pipe'];
// Dev: uses pythonw.exe (no console)
// Prod: PyInstaller exe with console=False
```

Crash recovery: exponential back-off (3.5s × min(restarts, 3)), max 5 restarts.

---

## Security Compliance

| Control | Detection Method |
|---------|-----------------|
| **Antivirus** | `Get-WmiObject root/SecurityCenter2 AntiVirusProduct` → `productState` bitmask |
| **BitLocker** | `Get-BitLockerVolume` → `ProtectionStatus` per drive |
| **Firewall** | `Get-NetFirewallProfile` → `Enabled` on Domain/Private/Public |

Compliance score: `100 - (AV off: -35) - (BitLocker off: -25) - (FW off: -25) - (suspicious procs: max -15) - (net anomalies: max -10)`

---

## Known Issues & Fixes Applied

| Issue | Fix |
|-------|-----|
| `NameError: psutil is not defined` (ServiceNow) | `import psutil` at module top level |
| `AttributeError: 'ProcessInfo' .get()` (AppCollector) | `isinstance(p, dict)` guard for both dict and dataclass inputs |
| `AttributeError: 'AgentState' .health` | Corrected to `.latest_health`, `.active_violations`, `.latest_context` |
| ServiceNow `get_alerts()` AttributeError | Updated to `get_all_alerts(200)` with `.id`, `.metric` attributes |
| CMD console popup on Windows | `CREATE_NO_WINDOW` + `pythonw.exe` + `windowsHide: true` |
| `_plat3` NameError in ServiceNow | All local platform imports removed; module-level `import platform as _platform` |

---

## Build Pipeline

```
python copy_renderer.py          → renderer/index.html
python backend_build.py          → backend_dist/SysAssistBackend.exe
npm install && npm run build
  → dist/Workplace Assist Setup 1.0.0.exe
     ├─ NSIS installer (compression: maximum)
     ├─ ASAR (JS only — no Python source included)
     └─ extraResources: SysAssistBackend.exe
```

---

## Windows Service

```bash
python install_agent.py    # install + register at startup
python uninstall_agent.py  # remove
sc start CognixEUDAgent
sc stop  CognixEUDAgent
```

---

## Telemetry & Privacy

- All AI processing is local (Ollama) or direct API (Claude/OpenAI)
- No telemetry to Cognix or third parties
- No analytics, crash reporting, or usage tracking
- API keys: memory only — never persisted
- Alert history: Fernet-encrypted local storage

---

## License

MIT — Copyright © 2026 Cognix
