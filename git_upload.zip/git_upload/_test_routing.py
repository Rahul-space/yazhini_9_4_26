import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ai.diagnostic import _classify_intent, _direct_sys_match

msgs = [
    "Arrange my desktop icons",
    "rearrange desktop icons",
    "set dark mode",
    "lock my screen",
    "take screenshot",
    "show desktop",
    "mute",
    "clear clipboard",
    "What is my CPU usage",
    "kill the top process",
    "Who is the president",
]

with open("_test_out.txt", "w", encoding="utf-8") as f:
    for m in msgs:
        intent = _classify_intent(m)
        dm = _direct_sys_match(m)
        tool = dm[0] if dm else "-"
        f.write("[%s] [%s] %s\n" % (intent, tool, m))
    f.write("ALL DONE\n")

print("Test written to _test_out.txt")
