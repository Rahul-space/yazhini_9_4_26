"""
SysAssist Agent Uninstaller
===========================
Stops and removes the Windows service and startup registration.

Run as Administrator:
    python uninstall_agent.py
  or:
    SysAssist.exe --uninstall
"""

import sys
import os
import platform
import subprocess
import ctypes
import time

_ROOT = os.path.dirname(os.path.abspath(__file__))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)
if getattr(sys, "frozen", False):
    sys.path.insert(0, sys._MEIPASS)


def _is_admin() -> bool:
    try:
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except Exception:
        return os.getuid() == 0 if hasattr(os, "getuid") else False


def step(msg):  print(f"\n  ➤ {msg}")
def ok(msg):    print(f"    ✓ {msg}")
def warn(msg):  print(f"    ⚠ {msg}")
def fail(msg):  print(f"    ✗ {msg}")


# ── Kill tray process ──────────────────────────────────────────────────────

def kill_tray_process():
    step("Stopping SysAssist tray process")
    try:
        import psutil
        killed = 0
        for proc in psutil.process_iter(["pid", "name", "cmdline"]):
            try:
                cmd = " ".join(proc.info.get("cmdline") or []).lower()
                name = (proc.info.get("name") or "").lower()
                if "sysassist" in name or ("tray_app" in cmd) or ("sysassist" in cmd and "--tray" in cmd):
                    proc.terminate()
                    killed += 1
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        if killed:
            ok(f"Stopped {killed} tray process(es)")
        else:
            ok("No tray process found (already stopped)")
    except ImportError:
        warn("psutil not available — skipping tray process kill")
    except Exception as exc:
        warn(f"Could not kill tray: {exc}")


# ── Windows service removal ────────────────────────────────────────────────

def remove_windows_service():
    step("Removing Windows Service (SysAssistAgent)")
    try:
        from service.windows_service import stop_service, remove_service, service_status

        status = service_status()
        if "NOT INSTALLED" in status:
            ok("Service is not installed — nothing to remove")
            return True

        if "RUNNING" in status:
            ok("Stopping service …")
            stop_service()
            time.sleep(3)

        if remove_service():
            ok("Service removed successfully")
            return True
        else:
            fail("Could not remove service")
            return False

    except ImportError:
        warn("pywin32 not available — checking with sc.exe")
        try:
            from config.settings import settings
            subprocess.run(["sc", "stop", settings.service_name], capture_output=True)
            time.sleep(2)
            result = subprocess.run(
                ["sc", "delete", settings.service_name], capture_output=True, text=True
            )
            if result.returncode == 0:
                ok("Service removed via sc.exe")
                return True
            warn(result.stderr.strip() or "sc.exe returned non-zero")
            return False
        except Exception as exc:
            fail(f"sc.exe removal failed: {exc}")
            return False
    except Exception as exc:
        fail(f"Service removal error: {exc}")
        return False


# ── Remove startup entry ───────────────────────────────────────────────────

def remove_startup_entry():
    step("Removing startup registration")
    if platform.system() != "Windows":
        warn("Startup removal only supported on Windows")
        return False
    try:
        import winreg
        key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE
        ) as reg_key:
            try:
                winreg.DeleteValue(reg_key, "SysAssistTray")
                ok("Startup entry removed")
            except FileNotFoundError:
                ok("Startup entry not found (already removed)")
        return True
    except Exception as exc:
        fail(f"Startup removal failed: {exc}")
        return False


# ── Remove firewall rule ───────────────────────────────────────────────────

def remove_firewall_rule():
    step("Removing Windows Firewall rule")
    try:
        result = subprocess.run(
            ["netsh", "advfirewall", "firewall", "delete", "rule",
             'name="SysAssist AI Dashboard"'],
            capture_output=True, text=True
        )
        if result.returncode == 0:
            ok("Firewall rule removed")
        else:
            ok("Firewall rule not found (already removed)")
        return True
    except Exception as exc:
        warn(f"Firewall rule removal error: {exc}")
        return False


# ── Optional: clear data ───────────────────────────────────────────────────

def clear_data(confirm: bool = False):
    step("Clearing local data and logs")
    if not confirm:
        answer = input("    Delete all SysAssist data and logs? [y/N]: ").strip().lower()
        confirm = answer == "y"

    if not confirm:
        ok("Data retained (skipped)")
        return

    import shutil
    from config.settings import settings
    for d in [settings.data_dir, settings.log_dir]:
        try:
            if d.exists():
                shutil.rmtree(d)
                ok(f"Deleted {d}")
        except Exception as exc:
            warn(f"Could not delete {d}: {exc}")


# ── Main ───────────────────────────────────────────────────────────────────

def main():
    print("""
╔══════════════════════════════════════════════════════════╗
║         SysAssist Agent Uninstaller  v2.2.0              ║
╚══════════════════════════════════════════════════════════╝""")

    if platform.system() != "Windows":
        print("\n  Uninstaller is for Windows only.")
        sys.exit(0)

    if not _is_admin():
        print("""
  ⚠  Administrator privileges required.
  Please run as Administrator.
""")
        try:
            ctypes.windll.shell32.ShellExecuteW(
                None, "runas", sys.executable,
                " ".join(f'"{a}"' for a in sys.argv),
                None, 1
            )
        except Exception:
            pass
        sys.exit(1)

    kill_tray_process()
    remove_windows_service()
    remove_startup_entry()
    remove_firewall_rule()
    clear_data(confirm=False)

    print("""
╔══════════════════════════════════════════════════════════╗
║              UNINSTALL COMPLETE                          ║
╠══════════════════════════════════════════════════════════╣
║  SysAssist has been fully removed from this device.      ║
║  Service stopped, startup entry cleared, rules removed.  ║
╚══════════════════════════════════════════════════════════╝
""")


if __name__ == "__main__":
    import multiprocessing
    multiprocessing.freeze_support()
    main()
