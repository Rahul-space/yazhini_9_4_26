"""
Encrypted Local Storage
Persists agent state, alert history, and metric snapshots between restarts.
Uses Fernet symmetric encryption (from cryptography package) with a
machine-unique key derived from the device's hardware identifiers.
Falls back to plain JSON if cryptography is not installed.
"""

import json
import os
import sys
import hashlib
import logging
import threading
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)

# ── Key derivation ─────────────────────────────────────────────────────────

def _derive_machine_key() -> bytes:
    """
    Derive a 32-byte key unique to this machine.
    Uses hostname + CPU count + platform as entropy source.
    Not cryptographically perfect but sufficient for local data protection.
    """
    import platform
    seed = (
        platform.node()
        + str(os.cpu_count())
        + platform.machine()
        + platform.processor()[:20]
        + "SysAssist-2.2.0-salt"
    )
    return hashlib.sha256(seed.encode()).digest()


def _get_fernet():
    """Return a Fernet instance or None if cryptography not installed."""
    try:
        from cryptography.fernet import Fernet
        import base64
        key   = base64.urlsafe_b64encode(_derive_machine_key())
        return Fernet(key)
    except ImportError:
        return None


# ── Storage class ──────────────────────────────────────────────────────────

class LocalStorage:
    """
    Key-value store that persists data to encrypted JSON files on disk.
    Each "namespace" maps to a separate file (e.g. alerts.enc, state.enc).
    Thread-safe.
    """

    def __init__(self, data_dir: Path, encrypt: bool = True):
        self._dir     = data_dir
        self._dir.mkdir(parents=True, exist_ok=True)
        self._fernet  = _get_fernet() if encrypt else None
        self._encrypt = encrypt and (self._fernet is not None)
        self._cache:  dict[str, dict] = {}
        self._lock    = threading.Lock()

        if encrypt and self._fernet is None:
            logger.warning(
                "cryptography package not installed — storage will use plain JSON. "
                "Install with: pip install cryptography"
            )
        else:
            logger.debug(f"Storage: {'encrypted' if self._encrypt else 'plain'} → {data_dir}")

    # ── Public API ─────────────────────────────────────────────────────────

    def get(self, namespace: str, key: str, default: Any = None) -> Any:
        with self._lock:
            store = self._load_namespace(namespace)
            return store.get(key, default)

    def set(self, namespace: str, key: str, value: Any):
        with self._lock:
            store = self._load_namespace(namespace)
            store[key] = value
            self._save_namespace(namespace, store)

    def delete(self, namespace: str, key: str):
        with self._lock:
            store = self._load_namespace(namespace)
            store.pop(key, None)
            self._save_namespace(namespace, store)

    def get_all(self, namespace: str) -> dict:
        with self._lock:
            return dict(self._load_namespace(namespace))

    def clear_namespace(self, namespace: str):
        with self._lock:
            self._cache.pop(namespace, None)
            path = self._path(namespace)
            if path.exists():
                path.unlink()

    # ── Internal ───────────────────────────────────────────────────────────

    def _path(self, namespace: str) -> Path:
        ext = ".enc" if self._encrypt else ".json"
        return self._dir / f"{namespace}{ext}"

    def _load_namespace(self, namespace: str) -> dict:
        if namespace in self._cache:
            return self._cache[namespace]

        path = self._path(namespace)
        if not path.exists():
            self._cache[namespace] = {}
            return {}

        try:
            raw = path.read_bytes()
            if self._encrypt and self._fernet:
                raw = self._fernet.decrypt(raw)
            data = json.loads(raw.decode("utf-8"))
            self._cache[namespace] = data
            return data
        except Exception as exc:
            logger.warning(f"Could not load storage namespace '{namespace}': {exc}")
            self._cache[namespace] = {}
            return {}

    def _save_namespace(self, namespace: str, data: dict):
        self._cache[namespace] = data
        path = self._path(namespace)
        try:
            raw = json.dumps(data, default=str).encode("utf-8")
            if self._encrypt and self._fernet:
                raw = self._fernet.encrypt(raw)
            path.write_bytes(raw)
        except Exception as exc:
            logger.error(f"Could not save storage namespace '{namespace}': {exc}")


# ── Module-level singleton (lazily initialised) ────────────────────────────
_storage_instance: Optional[LocalStorage] = None
_storage_lock = threading.Lock()


def get_storage() -> LocalStorage:
    global _storage_instance
    with _storage_lock:
        if _storage_instance is None:
            from config.settings import settings
            _storage_instance = LocalStorage(
                data_dir = settings.data_dir,
                encrypt  = settings.encrypt_storage,
            )
    return _storage_instance
