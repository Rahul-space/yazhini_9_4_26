"""
Log Manager
Sets up rotating file logs + console output.
All modules use standard logging; this configures the root handlers.
"""

import logging
import logging.handlers
import os
import sys
from pathlib import Path


def setup_logging(
    level: str = "INFO",
    log_dir: Path = None,
    max_bytes: int = 5_242_880,   # 5 MB
    backup_count: int = 5,
    name: str = "sysassist",
) -> logging.Logger:
    """
    Configure root logger with:
      - RotatingFileHandler  (log_dir/sysassist.log, 5 MB × 5 backups)
      - StreamHandler        (stdout, only if not running as a service)

    Returns the root 'sysassist' logger.
    """
    numeric_level = getattr(logging, level.upper(), logging.INFO)

    fmt = logging.Formatter(
        fmt     = "%(asctime)s [%(name)-22s] %(levelname)-8s %(message)s",
        datefmt = "%Y-%m-%d %H:%M:%S",
    )

    root = logging.getLogger(name)
    root.setLevel(numeric_level)

    # Prevent duplicate handlers on reload
    root.handlers.clear()

    # ── File handler ───────────────────────────────────────────────────────
    if log_dir is None:
        if getattr(sys, "frozen", False):
            log_dir = Path(sys.executable).parent / "logs"
        else:
            log_dir = Path(__file__).parent.parent / "logs"

    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / f"{name}.log"

    fh = logging.handlers.RotatingFileHandler(
        filename    = log_file,
        maxBytes    = max_bytes,
        backupCount = backup_count,
        encoding    = "utf-8",
    )
    fh.setFormatter(fmt)
    fh.setLevel(numeric_level)
    root.addHandler(fh)

    # ── Console handler (skip when running as a Windows service) ──────────
    _is_service = os.environ.get("SYSASSIST_SERVICE_MODE") == "1"
    if not _is_service:
        sh = logging.StreamHandler(sys.stdout)
        sh.setFormatter(fmt)
        sh.setLevel(numeric_level)
        root.addHandler(sh)

    # Silence noisy third-party loggers
    for noisy in ("uvicorn.access", "uvicorn.error", "httpcore", "httpx",
                  "urllib3", "asyncio", "multiprocessing"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    root.info(f"Logging initialised → {log_file}")
    return root


def get_logger(module_name: str) -> logging.Logger:
    """Get a child logger under the 'sysassist' namespace."""
    return logging.getLogger(f"sysassist.{module_name}")


class CrashHandler:
    """
    Installs a global exception hook that logs uncaught exceptions
    instead of letting them print to stderr and die silently.
    """

    def __init__(self, logger: logging.Logger):
        self._logger = logger
        sys.excepthook = self._handle

    def _handle(self, exc_type, exc_value, exc_tb):
        if issubclass(exc_type, KeyboardInterrupt):
            sys.__excepthook__(exc_type, exc_value, exc_tb)
            return
        self._logger.critical(
            "Uncaught exception", exc_info=(exc_type, exc_value, exc_tb)
        )
