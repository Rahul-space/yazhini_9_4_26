"""
SysAssist Agent Installer
=========================
Registers SysAssist as a Windows service AND adds the tray application
to the user's startup programs.

Run as Administrator:
    python install_agent.py
  or (after building):
    SysAssist.exe --install
"""

import sys
import os
import platform
import subprocess
import shutil
import ctypes
import time

# ── Ensure project root on path ────────────────────────────────────────────
_ROOT = os.path.dirname(os.path.abspath(__file__))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)
if getattr(sys, "frozen", False):
    sys.path.insert(0, sys._MEIPASS)


def _is_admin() -> bool:
    try:
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except Exception:
        return os.getuid() == 0 if hasattr(os, "getuid") else False


def _exe_path() -> str:
    """Return path to this executable (either .exe or python script)."""
    if getattr(sys, "frozen", False):
        return sys.executable
    return sys.executable


def _script_path() -> str:
    return os.path.abspath(__file__)


def step(msg: str): print(f"\n  ➤ {msg}")
def ok(msg: str):   print(f"    ✓ {msg}")
def warn(msg: str): print(f"    ⚠ {msg}")
def fail(msg: str): print(f"    ✗ {msg}")


# ── Windows Service Installation ───────────────────────────────────────────

def install_windows_service() -> bool:
    step("Installing Windows Service (SysAssistAgent)")
    try:
        from service.windows_service import (
            install_service, start_service, service_status
        )

        status_before = service_status()
        if "RUNNING" in status_before or "STOPPED" in status_before:
            ok(f"Service already installed (status: {status_before})")
        else:
            if not install_service():
                fail("Service installation failed")
                return False

        # Start the service
        status = service_status()
        if "RUNNING" not in status:
            ok("Starting service …")
            start_service()
            time.sleep(3)
            status = service_status()

        ok(f"Service status: {service_status()}")
        return True

    except ImportError:
        warn("pywin32 not available — skipping Windows service installation")
        warn("Install with: pip install pywin32")
        return False
    except Exception as exc:
        fail(f"Service error: {exc}")
        return False


# ── Startup Tray Registration ──────────────────────────────────────────────

def register_startup_tray() -> bool:
    """Add tray app to Windows startup (HKCU — no admin required)."""
    step("Registering tray app in Windows startup")

    if platform.system() != "Windows":
        warn("Startup registration only supported on Windows")
        return False

    try:
        import winreg
        key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
        exe      = _exe_path()

        if getattr(sys, "frozen", False):
            cmd = f'"{exe}" --tray'
        else:
            tray_script = os.path.join(_ROOT, "tray_app.py")
            cmd = f'"{sys.executable}" "{tray_script}"'

        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE
        ) as reg_key:
            winreg.SetValueEx(reg_key, "SysAssistTray", 0, winreg.REG_SZ, cmd)

        ok(f"Tray app registered: {cmd}")
        return True

    except Exception as exc:
        fail(f"Startup registration failed: {exc}")
        return False


# ── Firewall Rule ──────────────────────────────────────────────────────────

def add_firewall_rule() -> bool:
    """Allow SysAssist's local port through Windows Firewall (loopback only)."""
    step("Adding Windows Firewall rule for port 8765")
    try:
        from config.settings import settings
        port = settings.port
        rule_name = "SysAssist AI Dashboard"

        # Delete old rule if exists
        subprocess.run(
            ["netsh", "advfirewall", "firewall", "delete", "rule", f'name="{rule_name}"'],
            capture_output=True
        )

        # Add new rule for localhost only
        result = subprocess.run(
            [
                "netsh", "advfirewall", "firewall", "add", "rule",
                f"name={rule_name}",
                "protocol=TCP",
                "dir=in",
                f"localport={port}",
                "localip=127.0.0.1",
                "action=allow",
                "profile=any",
            ],
            capture_output=True, text=True
        )
        if result.returncode == 0:
            ok(f"Firewall rule added for port {port} (localhost only)")
            return True
        else:
            warn(f"Firewall rule failed: {result.stderr.strip()}")
            return False
    except Exception as exc:
        warn(f"Firewall rule error: {exc}")
        return False


# ── Launch Tray Now ────────────────────────────────────────────────────────

def launch_tray_now():
    """Start the tray application immediately (for the current session)."""
    step("Launching tray application")
    try:
        if getattr(sys, "frozen", False):
            exe = _exe_path()
            subprocess.Popen([exe, "--tray"], creationflags=0x00000008)  # DETACHED_PROCESS
        else:
            tray_script = os.path.join(_ROOT, "tray_app.py")
            subprocess.Popen(
                [sys.executable, tray_script],
                creationflags=subprocess.DETACHED_PROCESS
                if platform.system() == "Windows" else 0
            )
        ok("Tray application started")
    except Exception as exc:
        warn(f"Could not launch tray: {exc}")


# ── Main ───────────────────────────────────────────────────────────────────

def main():
    print("""
╔══════════════════════════════════════════════════════════╗
║         SysAssist Agent Installer  v2.2.0                ║
╚══════════════════════════════════════════════════════════╝""")

    if platform.system() != "Windows":
        print("\n  This installer is for Windows only.")
        print("  On Linux/macOS, run: python main.py\n")
        sys.exit(0)

    if not _is_admin():
        print("""
  ⚠  Administrator privileges required for service installation.
  
  Please right-click this file and choose "Run as administrator"
  OR run from an elevated command prompt:
  
      Right-click CMD → Run as Administrator
      cd path\\to\\sysassist
      python install_agent.py
""")
        # Try to re-launch elevated
        try:
            ctypes.windll.shell32.ShellExecuteW(
                None, "runas", sys.executable,
                " ".join(f'"{a}"' for a in sys.argv),
                None, 1
            )
        except Exception:
            pass
        sys.exit(1)

    results = {}
    results["service"]  = install_windows_service()
    results["startup"]  = register_startup_tray()
    results["firewall"] = add_firewall_rule()
    launch_tray_now()

    from config.settings import settings
    print(f"""
╔══════════════════════════════════════════════════════════╗
║              INSTALLATION COMPLETE                       ║
╠══════════════════════════════════════════════════════════╣
║  Service  : {'✓ Installed & Running' if results.get('service') else '⚠ Manual start required'}
║  Startup  : {'✓ Tray starts on login' if results.get('startup') else '⚠ Not registered'}
║  Firewall : {'✓ Port 8765 allowed' if results.get('firewall') else '⚠ Manual exception needed'}
║                                                          ║
║  Dashboard: {settings.dashboard_url:<45s}║
║                                                          ║
║  SysAssist runs automatically on every system boot.      ║
║  Look for the tray icon in the notification area.        ║
╚══════════════════════════════════════════════════════════╝
""")


if __name__ == "__main__":
    import multiprocessing
    multiprocessing.freeze_support()
    main()
