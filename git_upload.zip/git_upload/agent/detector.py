"""
Threshold Detection Engine — v2.2.0
Reads thresholds from config/settings.py (hot-reloadable).
Sustained violation: ≥ sustained_ratio of window samples exceed threshold.
"""

from dataclasses import dataclass
from enum import Enum
from agent.buffer import MetricBuffers
from config.settings import settings


class Severity(str, Enum):
    INFO     = "info"
    WARNING  = "warning"
    CRITICAL = "critical"


@dataclass
class ThresholdViolation:
    metric:           str
    current_value:    float
    threshold:        float
    severity:         Severity
    message:          str
    sustained_seconds:float


# Metric → (buffer attribute, human label, sample interval key)
_METRIC_MAP = [
    ("cpu",             "cpu",             "CPU",             "cpu"),
    ("memory",          "memory",          "Memory",          "memory"),
    ("disk",            "disk",            "Disk",            "disk"),
    ("gpu",             "gpu",             "GPU",             "gpu"),
    ("network_latency", "network_latency", "Network Latency", "network"),
]


class ThresholdDetector:

    def check_violations(self, buffers: MetricBuffers) -> list[ThresholdViolation]:
        violations: list[ThresholdViolation] = []
        thresholds     = settings.thresholds          # dict from config
        sustained_ratio= settings.sustained_ratio     # 0.70 default
        intervals      = settings.intervals

        for config_key, buf_attr, label, interval_key in _METRIC_MAP:
            buf    = getattr(buffers, buf_attr, None)
            if buf is None:
                continue
            values = buf.values()
            if len(values) < 3:
                continue

            current      = values[-1]
            metric_thresh= thresholds.get(config_key, {})
            interval     = intervals.get(interval_key, 5)

            for level in ("critical", "warning"):
                threshold = metric_thresh.get(level)
                if threshold is None:
                    continue

                exceeding = sum(1 for v in values if v >= threshold)
                ratio     = exceeding / len(values)

                if ratio >= sustained_ratio:
                    sustained = len(values) * interval
                    violations.append(ThresholdViolation(
                        metric           = config_key,
                        current_value    = round(current, 1),
                        threshold        = threshold,
                        severity         = Severity.CRITICAL if level == "critical" else Severity.WARNING,
                        message          = self._msg(label, current, threshold, level, sustained),
                        sustained_seconds= sustained,
                    ))
                    break   # report highest severity only per metric

        return violations

    @staticmethod
    def _msg(label: str, value: float, threshold: float,
             level: str, sustained_s: float) -> str:
        unit = "ms" if label == "Network Latency" else "%"
        mins = int(sustained_s // 60)
        secs = int(sustained_s % 60)
        dur  = f"{mins}m {secs}s" if mins else f"{secs}s"
        return (
            f"{label} {level.upper()}: {value:.1f}{unit} "
            f"(threshold: {threshold}{unit}) sustained for {dur}"
        )
