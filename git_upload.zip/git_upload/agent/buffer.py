"""
Rolling buffer implementation for storing metric history.
Maintains a sliding window of samples for trend and threshold analysis.
"""
from collections import deque
from dataclasses import dataclass, field
from typing import Deque, Optional
import time


@dataclass
class MetricSample:
    value: float
    timestamp: float = field(default_factory=time.time)


class RollingBuffer:
    """Thread-safe rolling buffer for metric samples."""

    def __init__(self, maxlen: int = 12):
        self.maxlen = maxlen
        self._buffer: Deque[MetricSample] = deque(maxlen=maxlen)

    def add(self, value: float) -> None:
        self._buffer.append(MetricSample(value=value))

    def values(self) -> list[float]:
        return [s.value for s in self._buffer]

    def timestamps(self) -> list[float]:
        return [s.timestamp for s in self._buffer]

    def latest(self) -> Optional[float]:
        return self._buffer[-1].value if self._buffer else None

    def average(self) -> Optional[float]:
        vals = self.values()
        return sum(vals) / len(vals) if vals else None

    def is_full(self) -> bool:
        return len(self._buffer) == self.maxlen

    def __len__(self) -> int:
        return len(self._buffer)


class MetricBuffers:
    """Central store for all system metric buffers."""

    def __init__(self, window_size: int = 12):
        self.cpu = RollingBuffer(window_size)
        self.memory = RollingBuffer(window_size)
        self.disk = RollingBuffer(window_size)
        self.gpu = RollingBuffer(window_size)
        self.network_sent = RollingBuffer(window_size)
        self.network_recv = RollingBuffer(window_size)
        self.network_latency = RollingBuffer(window_size)
        self.disk_io_read = RollingBuffer(window_size)
        self.disk_io_write = RollingBuffer(window_size)

    def snapshot(self) -> dict:
        return {
            "cpu": self.cpu.values(),
            "memory": self.memory.values(),
            "disk": self.disk.values(),
            "gpu": self.gpu.values(),
            "network_sent": self.network_sent.values(),
            "network_recv": self.network_recv.values(),
            "network_latency": self.network_latency.values(),
            "disk_io_read": self.disk_io_read.values(),
            "disk_io_write": self.disk_io_write.values(),
        }
