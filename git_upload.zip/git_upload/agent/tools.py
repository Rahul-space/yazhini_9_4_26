from agent.scheduler import MetricScheduler
from agent.battery import BatteryCollector
from agent.app_collector import AppCollector
from agent.security import _check_antivirus, _check_bitlocker, _check_firewall, _check_suspicious_processes

# Shared instances
scheduler = MetricScheduler()
battery_collector = BatteryCollector()
app_collector = AppCollector()


# =========================
# 📊 SYSTEM TOOLS
# =========================

def get_system_health() -> str:
    ctx = scheduler.state.latest_context
    if not ctx:
        return "No system data available"
    return ctx.to_prompt_text()


def get_cpu_usage() -> str:
    m = scheduler.state.latest_metrics
    return f"CPU Usage: {m.cpu_percent}%" if m else "No data"


def get_memory_usage() -> str:
    m = scheduler.state.latest_metrics
    return f"Memory Usage: {m.memory_percent}%" if m else "No data"


def get_top_processes() -> str:
    procs = scheduler.state.latest_processes
    return str([{"name": p.name, "cpu": p.cpu_percent} for p in procs[:5]])


# =========================
# 🔋 BATTERY TOOL
# =========================

def get_battery_info() -> str:
    data = battery_collector.collect()
    return str(data)


# =========================
# 🖥️ APPLICATION TOOL
# =========================

def get_app_insights() -> str:
    apps = app_collector.collect()
    return str({k: v.health_score for k, v in list(apps.items())[:5]})


# =========================
# 🔐 SECURITY TOOL
# =========================

def get_security_status() -> str:
    return str({
        "antivirus": _check_antivirus(),
        "bitlocker": _check_bitlocker(),
        "firewall": _check_firewall(),
        "threats": _check_suspicious_processes()
    })


# =========================
# 🛠️ ACTION TOOLS (CONNECT YOUR actions.py)
# =========================

def kill_process(process_name: str) -> str:
    from remediation.actions import kill_process_by_name
    return kill_process_by_name(process_name)


def clear_temp_files() -> str:
    from remediation.actions import clear_temp
    return clear_temp()