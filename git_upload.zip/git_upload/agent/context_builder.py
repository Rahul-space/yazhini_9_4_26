"""
Context builder.
Assembles a rich diagnostic context object for the AI diagnostic engine.
"""
from dataclasses import dataclass, asdict
from typing import Optional
from agent.collector import SystemMetrics, ProcessInfo
from agent.detector import ThresholdViolation
from agent.analyzer import TrendResult, Prediction
from agent.health import HealthScore
import time


@dataclass
class DiagnosticContext:
    timestamp: float
    metrics: dict
    trends: dict
    predictions: list[dict]
    violations: list[dict]
    top_processes: list[dict]
    health: dict
    system_info: dict

    def to_dict(self) -> dict:
        return asdict(self)

    def to_prompt_text(self) -> str:
        """Convert context to a human-readable prompt for the AI."""
        lines = [
            "=== SYSTEM DIAGNOSTIC CONTEXT ===",
            f"Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(self.timestamp))}",
            "",
            f"HEALTH SCORE: {self.health.get('score', '?')}/100 ({self.health.get('label', '')})",
            self.health.get("summary", ""),
            "",
            "CURRENT METRICS:",
        ]

        m = self.metrics
        lines += [
            f"  CPU:     {m.get('cpu_percent', 0):.1f}% (freq: {m.get('cpu_freq_mhz', 0):.0f}MHz, cores: {m.get('cpu_core_count', 0)})",
            f"  Memory:  {m.get('memory_percent', 0):.1f}% ({m.get('memory_used_gb', 0):.1f}/{m.get('memory_total_gb', 0):.1f} GB)",
            f"  Disk:    {m.get('disk_percent', 0):.1f}% ({m.get('disk_used_gb', 0):.1f}/{m.get('disk_total_gb', 0):.1f} GB)",
            f"  Network: ↑{m.get('network_sent_mbps', 0):.1f} Mbps / ↓{m.get('network_recv_mbps', 0):.1f} Mbps (latency: {m.get('network_latency_ms', 0):.0f}ms)",
        ]

        if m.get("gpu_percent", 0) > 0:
            lines.append(f"  GPU:     {m.get('gpu_percent', 0):.1f}% ({m.get('gpu_name', 'GPU')})")

        lines.append("")
        lines.append("TRENDS:")
        for metric, trend in self.trends.items():
            if trend:
                lines.append(f"  {metric.upper()}: {trend.get('direction', '?')} "
                              f"(slope: {trend.get('slope', 0):+.2f}/sample, "
                              f"change: {trend.get('change_rate', 0):+.1f}%)")

        if self.predictions:
            lines.append("")
            lines.append("PREDICTIONS:")
            for pred in self.predictions:
                lines.append(f"  {pred.get('message', '')}")

        if self.violations:
            lines.append("")
            lines.append("ACTIVE VIOLATIONS:")
            for v in self.violations:
                lines.append(f"  [{v.get('severity', '').upper()}] {v.get('message', '')}")

        if self.top_processes:
            lines.append("")
            lines.append("TOP PROCESSES (by CPU):")
            for proc in self.top_processes[:8]:
                lines.append(f"  {proc.get('name', '?'):20s} PID:{proc.get('pid', '?'):6} "
                              f"CPU:{proc.get('cpu_percent', 0):5.1f}% "
                              f"MEM:{proc.get('memory_mb', 0):7.1f}MB "
                              f"({proc.get('status', '?')})")

        return "\n".join(lines)


class ContextBuilder:
    def build(
        self,
        metrics: SystemMetrics,
        trends: dict[str, Optional[TrendResult]],
        predictions: list[Optional[Prediction]],
        violations: list[ThresholdViolation],
        top_processes: list[ProcessInfo],
        health: HealthScore,
        system_info: dict,
    ) -> DiagnosticContext:
        return DiagnosticContext(
            timestamp=metrics.timestamp,
            metrics={
                "cpu_percent": metrics.cpu_percent,
                "cpu_freq_mhz": metrics.cpu_freq_mhz,
                "cpu_core_count": metrics.cpu_core_count,
                "memory_percent": metrics.memory_percent,
                "memory_used_gb": metrics.memory_used_gb,
                "memory_total_gb": metrics.memory_total_gb,
                "disk_percent": metrics.disk_percent,
                "disk_used_gb": metrics.disk_used_gb,
                "disk_total_gb": metrics.disk_total_gb,
                "disk_read_mbps": metrics.disk_read_mbps,
                "disk_write_mbps": metrics.disk_write_mbps,
                "gpu_percent": metrics.gpu_percent,
                "gpu_memory_percent": metrics.gpu_memory_percent,
                "gpu_name": metrics.gpu_name,
                "network_sent_mbps": metrics.network_sent_mbps,
                "network_recv_mbps": metrics.network_recv_mbps,
                "network_latency_ms": metrics.network_latency_ms,
            },
            trends={
                k: ({"direction": v.direction.value, "slope": v.slope,
                      "change_rate": v.change_rate, "confidence": v.confidence}
                    if v else None)
                for k, v in trends.items()
            },
            predictions=[
                {
                    "metric": p.metric,
                    "current_value": p.current_value,
                    "predicted_1h": p.predicted_value_1h,
                    "predicted_24h": p.predicted_value_24h,
                    "time_to_critical_hours": p.time_to_critical_hours,
                    "message": p.message,
                }
                for p in predictions if p is not None
            ],
            violations=[
                {
                    "metric": v.metric,
                    "current_value": v.current_value,
                    "threshold": v.threshold,
                    "severity": v.severity.value,
                    "message": v.message,
                    "sustained_seconds": v.sustained_seconds,
                }
                for v in violations
            ],
            top_processes=[
                {
                    "pid": p.pid,
                    "name": p.name,
                    "cpu_percent": p.cpu_percent,
                    "memory_mb": p.memory_mb,
                    "status": p.status,
                    "username": p.username,
                    "threads": p.threads,
                    "cpu_bar_color": p.cpu_bar_color,
                }
                for p in top_processes
            ],
            health={
                "score": health.score,
                "grade": health.grade,
                "label": health.label,
                "color": health.color,
                "breakdown": health.breakdown,
                "summary": health.summary,
            },
            system_info=system_info,
        )
