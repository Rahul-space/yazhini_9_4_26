"""
Async Metric Scheduler — v2.2.0
Orchestrates all collection loops with configurable intervals from config.json.
Supports pause/resume, config hot-reload, and auto-resolve of cleared violations.
"""

import asyncio
import time
import logging
from typing import Optional, Callable

from agent.buffer        import MetricBuffers
from agent.collector     import MetricsCollector, SystemMetrics, ProcessInfo
from agent.detector      import ThresholdDetector, ThresholdViolation
from agent.analyzer      import TrendAnalyzer, PredictiveAnalyzer
from agent.health        import HealthScoreEngine, HealthScore
from agent.context_builder import ContextBuilder, DiagnosticContext
from config.settings     import settings

logger = logging.getLogger(__name__)


class AgentState:
    """Shared mutable state readable by the API layer."""

    def __init__(self):
        self.latest_metrics: Optional[SystemMetrics]    = None
        self.latest_processes: list[ProcessInfo]        = []
        self.latest_context: Optional[DiagnosticContext]= None
        self.latest_health: Optional[HealthScore]       = None
        self.active_violations: list[ThresholdViolation]= []
        self.alert_callbacks: list[Callable]            = []
        self.system_info: dict                          = {}
        self.metric_history: list[dict]                 = []
        self.start_time: float                          = time.time()
        self.paused: bool                               = False

        # Buffers use window_size from config
        self.buffers = MetricBuffers(window_size=settings.window_size)

        # Track which metrics were previously violating (for auto-resolve)
        self._prev_violating: set = set()

    def push_metric_snapshot(self, m: SystemMetrics):
        snap = {
            "t":      round(m.timestamp),
            "cpu":    round(m.cpu_percent, 1),
            "mem":    round(m.memory_percent, 1),
            "disk":   round(m.disk_percent, 1),
            "gpu":    round(m.gpu_percent, 1),
            "net_s":  round(m.network_sent_mbps, 2),
            "net_r":  round(m.network_recv_mbps, 2),
            "lat":    round(m.network_latency_ms, 1),
            "disk_r": round(m.disk_read_mbps, 2),
            "disk_w": round(m.disk_write_mbps, 2),
        }
        self.metric_history.append(snap)
        if len(self.metric_history) > 60:
            self.metric_history.pop(0)


class MetricScheduler:
    """Runs all monitoring tasks as asyncio coroutines."""

    def __init__(self):
        self.state   = AgentState()
        self._col    = MetricsCollector()
        self._det    = ThresholdDetector()
        self._trend  = TrendAnalyzer()
        self._pred   = PredictiveAnalyzer()
        self._health = HealthScoreEngine()
        self._ctx    = ContextBuilder()
        self._running = False
        self._tasks: list[asyncio.Task] = []

        # Prime psutil CPU counter (first call always returns 0)
        import psutil
        psutil.cpu_percent(interval=None)

        self.state.system_info = self._col.get_system_info()

    async def start(self):
        self._running = True
        logger.info("MetricScheduler starting …")

        ivs = settings.intervals  # pull once; config may be reloaded later

        self._tasks = [
            asyncio.create_task(self._cpu_loop(),       name="cpu"),
            asyncio.create_task(self._memory_loop(),    name="memory"),
            asyncio.create_task(self._disk_loop(),      name="disk"),
            asyncio.create_task(self._network_loop(),   name="network"),
            asyncio.create_task(self._process_loop(),   name="process"),
            asyncio.create_task(self._analysis_loop(),  name="analysis"),
        ]
        await asyncio.gather(*self._tasks, return_exceptions=True)

    async def stop(self):
        self._running = False
        for t in self._tasks:
            t.cancel()

    # ── Collection loops ───────────────────────────────────────────────────

    async def _cpu_loop(self):
        import psutil
        interval = settings.intervals.get("cpu", 5)
        while self._running:
            if not self.state.paused:
                try:
                    cpu = psutil.cpu_percent(interval=1)
                    self.state.buffers.cpu.add(cpu)
                except Exception as exc:
                    logger.debug(f"CPU collect error: {exc}")
                await asyncio.sleep(max(1, interval - 1))
            else:
                await asyncio.sleep(2)

    async def _memory_loop(self):
        import psutil
        interval = settings.intervals.get("memory", 10)
        while self._running:
            if not self.state.paused:
                try:
                    mem = psutil.virtual_memory().percent
                    self.state.buffers.memory.add(mem)
                except Exception as exc:
                    logger.debug(f"Memory collect error: {exc}")
                await asyncio.sleep(interval)
            else:
                await asyncio.sleep(2)

    async def _disk_loop(self):
        import psutil
        interval = settings.intervals.get("disk", 60)
        while self._running:
            if not self.state.paused:
                try:
                    disk = psutil.disk_usage("/").percent
                    self.state.buffers.disk.add(disk)
                except Exception as exc:
                    logger.debug(f"Disk collect error: {exc}")
                await asyncio.sleep(interval)
            else:
                await asyncio.sleep(2)

    async def _network_loop(self):
        """Full metrics collection (network + disk I/O + GPU)."""
        interval = settings.intervals.get("network", 30)
        while self._running:
            if not self.state.paused:
                try:
                    m = await asyncio.get_event_loop().run_in_executor(
                        None, self._col.collect
                    )
                    self.state.buffers.network_sent.add(m.network_sent_mbps)
                    self.state.buffers.network_recv.add(m.network_recv_mbps)
                    self.state.buffers.network_latency.add(m.network_latency_ms)
                    self.state.buffers.disk_io_read.add(m.disk_read_mbps)
                    self.state.buffers.disk_io_write.add(m.disk_write_mbps)
                    if m.gpu_percent > 0:
                        self.state.buffers.gpu.add(m.gpu_percent)
                    self.state.latest_metrics = m
                    self.state.push_metric_snapshot(m)
                except Exception as exc:
                    logger.debug(f"Network/full collect error: {exc}")
                await asyncio.sleep(interval)
            else:
                await asyncio.sleep(2)

    async def _process_loop(self):
        interval = settings.intervals.get("processes", 10)
        while self._running:
            if not self.state.paused:
                try:
                    procs = await asyncio.get_event_loop().run_in_executor(
                        None, self._col.get_top_processes, 15
                    )
                    self.state.latest_processes = procs
                except Exception as exc:
                    logger.debug(f"Process collect error: {exc}")
                await asyncio.sleep(interval)
            else:
                await asyncio.sleep(2)

    # ── Analysis loop ──────────────────────────────────────────────────────

    async def _analysis_loop(self):
        """
        Runs every analysis_interval seconds:
          1. Threshold detection
          2. Trend analysis
          3. Predictive analysis
          4. Health score
          5. Context build
          6. Auto-resolve cleared violations
          7. Fire alert callbacks
        """
        await asyncio.sleep(5)   # brief startup delay
        interval = settings.intervals.get("analysis", 15)

        while self._running:
            if not self.state.paused:
                try:
                    await self._analyse()
                except Exception as exc:
                    logger.warning(f"Analysis error: {exc}")
                await asyncio.sleep(interval)
            else:
                await asyncio.sleep(2)

    async def _analyse(self):
        bufs    = self.state.buffers
        metrics = self.state.latest_metrics
        if metrics is None:
            return

        # ── Threshold detection ────────────────────────────────────────────
        violations = self._det.check_violations(bufs)
        self.state.active_violations = violations

        # ── Auto-resolve metrics that are no longer violating ──────────────
        now_violating = {v.metric for v in violations}
        newly_resolved= self.state._prev_violating - now_violating
        if newly_resolved:
            try:
                # Import lazily to avoid circular imports at module load
                from alerts.manager import AlertManager
                # We don't have a direct reference; fire resolve via state_manager
                from alerts.state_manager import alert_state_manager
                for metric in newly_resolved:
                    alert_state_manager.on_violation_cleared(metric)
                    logger.info(f"[{metric}] violation cleared — auto-resolved")
            except Exception as exc:
                logger.debug(f"Auto-resolve error: {exc}")
        self.state._prev_violating = now_violating

        # ── Trend analysis ─────────────────────────────────────────────────
        ivs = settings.intervals
        trends = {
            "cpu":             self._trend.analyze(bufs.cpu,             ivs.get("cpu", 5)),
            "memory":          self._trend.analyze(bufs.memory,          ivs.get("memory", 10)),
            "disk":            self._trend.analyze(bufs.disk,            ivs.get("disk", 60)),
            "network_latency": self._trend.analyze(bufs.network_latency, ivs.get("network", 30)),
        }

        # ── Predictive analysis ────────────────────────────────────────────
        predictions = []
        for metric, buf, interval in [
            ("cpu",    bufs.cpu,    ivs.get("cpu", 5)),
            ("memory", bufs.memory, ivs.get("memory", 10)),
            ("disk",   bufs.disk,   ivs.get("disk", 60)),
        ]:
            pred = self._pred.predict(metric, buf, interval)
            if pred:
                predictions.append(pred)

        # ── Health score ───────────────────────────────────────────────────
        health = self._health.compute(metrics)
        self.state.latest_health = health

        # ── Context build ──────────────────────────────────────────────────
        context = self._ctx.build(
            metrics      = metrics,
            trends       = trends,
            predictions  = predictions,
            violations   = violations,
            top_processes= self.state.latest_processes,
            health       = health,
            system_info  = self.state.system_info,
        )
        self.state.latest_context = context

        # ── Fire alert callbacks ───────────────────────────────────────────
        critical = [v for v in violations if v.severity.value == "critical"]
        if critical:
            for cb in self.state.alert_callbacks:
                try:
                    cb(context, critical)
                except Exception as exc:
                    logger.debug(f"Alert callback error: {exc}")
