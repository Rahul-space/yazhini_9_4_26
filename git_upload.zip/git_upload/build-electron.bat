@echo off
REM ══════════════════════════════════════════════════════════════
REM  SysAssist — Full Electron Build Script  (Fixed v2.2.1)
REM  Builds Python backend + Electron installer in one command.
REM ══════════════════════════════════════════════════════════════

echo.
echo ╔══════════════════════════════════════════════════════════╗
echo ║     SysAssist Full Build Pipeline  v2.2.1               ║
echo ╚══════════════════════════════════════════════════════════╝
echo.

REM ── Step 1: Python deps ──────────────────────────────────────
echo [1/6] Installing Python dependencies...
pip install -r requirements.txt --quiet --upgrade
if %ERRORLEVEL% neq 0 (
    echo ERROR: pip install failed
    echo Try running CMD as Administrator
    pause
    exit /b 1
)
echo     OK

REM ── Step 2: Sync renderer ─────────────────────────────────────
echo [2/6] Syncing renderer (ui/index.html → renderer/index.html)...
python copy_renderer.py
if %ERRORLEVEL% neq 0 (
    echo ERROR: copy_renderer.py failed
    pause
    exit /b 1
)

REM ── Step 3: Generate icons ────────────────────────────────────
echo [3/6] Generating tray icons...
python generate_icons.py
if %ERRORLEVEL% neq 0 (
    echo WARNING: Icon generation had issues - continuing with fallback icons
)

REM ── Step 4: Build Python backend ─────────────────────────────
echo [4/6] Building Python backend with PyInstaller (5-8 min)...
python backend_build.py
if %ERRORLEVEL% neq 0 (
    echo ERROR: Python backend build failed
    echo Check output above for PyInstaller errors
    pause
    exit /b 1
)

REM ── Step 5: Install Node.js deps ─────────────────────────────
echo [5/6] Installing Node.js dependencies...
call npm install
call npm install ws --save
if %ERRORLEVEL% neq 0 (
    echo ERROR: npm install failed
    echo Make sure Node.js 18+ is installed
    pause
    exit /b 1
)
echo     OK

REM ── Step 6: Build Electron installer ─────────────────────────
echo [6/6] Building Electron installer (2-3 min)...
call npm run build
if %ERRORLEVEL% neq 0 (
    echo ERROR: Electron build failed
    pause
    exit /b 1
)

echo.
echo ╔══════════════════════════════════════════════════════════╗
echo ║  BUILD COMPLETE  ✓                                       ║
echo ╠══════════════════════════════════════════════════════════╣
echo ║  INSTALLER: dist\SysAssist Setup 2.2.0.exe              ║
echo ║  PORTABLE:  dist\win-unpacked\SysAssist.exe             ║
echo ║                                                          ║
echo ║  Double-click the installer to install SysAssist.        ║
echo ║                                                          ║
echo ║  IF ANTIVIRUS BLOCKS THE EXE:                           ║
echo ║  Windows Security → Exclusions → Add → dist\ folder     ║
echo ╚══════════════════════════════════════════════════════════╝
echo.
pause
