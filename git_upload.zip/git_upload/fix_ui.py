"""
fix_ui.py — One-Command Fix for "UI not found" Error
=====================================================
If SysAssist shows "UI not found" after installing the .exe,
run this script to copy the ui/ folder to where the exe expects it.

Usage:
    python fix_ui.py

Works for:
  • Running from source (python main.py)
  • Installed via the NSIS installer
  • Portable (dist/win-unpacked/SysAssist.exe)
"""

import sys
import os
import shutil
from pathlib import Path

HERE = Path(__file__).parent.resolve()


def find_install_dir() -> list[Path]:
    """Return all directories where SysAssist.exe might be installed."""
    candidates = []

    # 1. Current project folder (running from source)
    candidates.append(HERE)

    # 2. Default NSIS install path  (per-user, no admin)
    appdata = os.environ.get("LOCALAPPDATA", "")
    if appdata:
        candidates.append(Path(appdata) / "Programs" / "SysAssist")
        candidates.append(Path(appdata) / "Programs" / "sysassist")

    # 3. Portable — dist/win-unpacked next to this script
    candidates.append(HERE / "dist" / "win-unpacked")

    # 4. System-wide install (admin)
    pf = os.environ.get("PROGRAMFILES", "C:\\Program Files")
    candidates.append(Path(pf) / "SysAssist")

    return [c for c in candidates if c.exists()]


def copy_ui_to(dest_dir: Path, ui_src: Path) -> bool:
    """Copy ui/index.html into dest_dir/ui/."""
    dest_ui = dest_dir / "ui"
    dest_html = dest_ui / "index.html"

    if dest_html.exists():
        print(f"  ✓  UI already present at: {dest_html}")
        return True

    try:
        dest_ui.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ui_src, dest_html)
        print(f"  ✓  Copied ui/index.html → {dest_html}")
        return True
    except Exception as exc:
        print(f"  ✗  Failed to copy to {dest_html}: {exc}")
        return False


def main():
    print("""
╔══════════════════════════════════════════════════════════╗
║         SysAssist — Fix "UI not found" Error             ║
╚══════════════════════════════════════════════════════════╝
""")

    # Find the ui/index.html source
    ui_src = HERE / "ui" / "index.html"
    if not ui_src.exists():
        # Try renderer/index.html as fallback
        ui_src = HERE / "renderer" / "index.html"
    if not ui_src.exists():
        print(f"  ✗  Cannot find ui/index.html or renderer/index.html")
        print(f"     Expected location: {HERE / 'ui' / 'index.html'}")
        print(f"\n  Make sure you run this script from inside the sysassist/ folder.")
        sys.exit(1)

    print(f"  ✓  Source UI: {ui_src}  ({ui_src.stat().st_size // 1024} KB)\n")

    # Find all install locations
    install_dirs = find_install_dir()
    print(f"  Found {len(install_dirs)} potential install location(s):\n")

    fixed = 0
    for d in install_dirs:
        exe = d / "SysAssist.exe"
        backend = d / "resources" / "backend" / "SysAssistBackend.exe"
        has_exe = exe.exists()
        has_backend = backend.exists()

        print(f"  📁  {d}")
        print(f"      SysAssist.exe:        {'✓ found' if has_exe else '✗ not here'}")
        print(f"      SysAssistBackend.exe: {'✓ found' if has_backend else '✗ not here'}")

        # Copy ui/ next to SysAssist.exe (for standalone PyInstaller build)
        if has_exe:
            if copy_ui_to(d, ui_src):
                fixed += 1

        # Copy ui/ into resources/backend/ (for Electron build)
        if has_backend:
            backend_dir = d / "resources" / "backend"
            if copy_ui_to(backend_dir, ui_src):
                fixed += 1

        # Also copy config/ if missing
        dest_config = d / "config" / "config.json"
        if has_exe and not dest_config.exists():
            cfg_src = HERE / "config" / "config.json"
            if cfg_src.exists():
                try:
                    (d / "config").mkdir(parents=True, exist_ok=True)
                    shutil.copy2(cfg_src, dest_config)
                    print(f"      ✓  Copied config/config.json → {dest_config}")
                except Exception as exc:
                    print(f"      ⚠  Could not copy config: {exc}")

        print()

    if fixed > 0:
        print(f"""
  ✓  Fixed {fixed} location(s).

  Now restart SysAssist:
    1. Right-click the tray icon → Quit SysAssist
    2. Double-click SysAssist.exe to relaunch
    3. The dashboard should load correctly now.

  OR if running from source:
    python main.py --agent   (in one terminal)
    npm start                (in another terminal)
""")
    else:
        print("""
  ⚠  No SysAssist installation found to fix.

  If you installed SysAssist in a custom location:
    1. Open File Explorer and find SysAssist.exe
    2. Create a folder called  ui\\  next to SysAssist.exe
    3. Copy  ui\\index.html  into it

  Or rebuild completely:
    build-electron.bat
""")


if __name__ == "__main__":
    main()
